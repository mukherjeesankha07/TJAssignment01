package stepDefinition;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.cucumber.datatable.DataTable;
import io.github.bonigarcia.wdm.WebDriverManager;
import junit.framework.Assert;

public class eLearningRegistration {
	WebDriver driver;
	
	@Given("Launch elearning website")
	public void launch_elearning_website() {
		WebDriverManager.chromedriver().setup();
		driver= new ChromeDriver();
	    driver.manage().window().maximize();  
	    driver.get("http://elearningm1.upskills.in/index.php");
	    System.out.println("Elearning Page opened");
	}

	@When("Submit Button is displayed")
	public void submit_Button_is_displayed() {
		System.out.println(driver.findElement(By.name("submitAuth")).isDisplayed());
	}

	@Then("click on signup")
	public void click_on_signup() {
		WebElement m = driver.findElement(By.xpath("//a[contains(text(),'Sign up!')]"));
		m.click();
		System.out.println("SignUp link clicked");
	}
	
	@When("Registration form is displayed")
	public void registration_form_is_displayed() {
	    //driver.findElement(By.xpath("//li[contains(text(),\"Registration\")]")).isDisplayed();
	    System.out.println(driver.findElement(By.name("firstname")).isDisplayed());
	    System.out.println("Registration Form displayed");
	}

	
	@Then("Fill up the Form")
	public void fill_up_the_Form(DataTable dataTable) {
		Map<String,String> data=dataTable.asMap(String.class, String.class);
		
		String usrnmval=data.get("UserName");
		LocalDateTime currentDateTime = LocalDateTime.now();
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("ddMMyyhhmmss");
		String formattedDateTime = currentDateTime.format(dtf);
		usrnmval=usrnmval.concat(formattedDateTime);
	    
	    driver.findElement(By.name("firstname")).sendKeys(data.get("FirstName"));
	    driver.findElement(By.name("lastname")).sendKeys(data.get("LastName"));
	    driver.findElement(By.name("email")).sendKeys(data.get("Email"));
	    driver.findElement(By.name("username")).sendKeys(usrnmval);
	    driver.findElement(By.name("pass1")).sendKeys(data.get("Pass"));
	    driver.findElement(By.name("pass2")).sendKeys(data.get("ConfPass"));
	    
	    System.out.println("Form Data entered");
	}

	@Then("Click on the Register Button")
	public void click_on_the_Register_Button() {
	    WebElement btn=driver.findElement(By.name("submit"));
	    btn.click();
	    
	    System.out.println("Register Button clicked");
	}

	
	@When("Success msg shown")
	public void success_msg_shown() {
		//Boolean succ=
		//driver.getPageSource().contains("Your personal settings have been registered.");
		
		List<WebElement> conftext = driver.findElements(By.tagName("p"));
		//System.out.println(conftext.size());
		for (WebElement webElement : conftext) 
		{
			String texts = webElement.getText();
			if(texts.contains("Your personal settings have been registered."))
			{
				System.out.println(texts + ": Text Verified");
			}
		
		}
	
	}

	@Then("Click on Next Button")
	public void click_on_Next_Button() {
		WebElement nxtbtn=driver.findElement(By.name("next"));
	    nxtbtn.click();
	    System.out.println("Next button clicked");
	}
	
	@When("Homepage is displayed")
	public void homepage_is_displayed() {
	    driver.findElement(By.xpath("//a[contains(@class,'dropdown-toggle')]")).isDisplayed();
	    System.out.println("Home Page displayed");
	    WebElement dd=driver.findElement(By.xpath("//a[contains(@class,'dropdown-toggle')]"));
	    dd.click();
	    System.out.println("Profile dropdown clicked");
	}

	@Then("Click Profile dropdown")
	public void click_Profile_dropdown() {
		
	    WebElement prof=driver.findElement(By.xpath("//ul[contains(@class,'dropdown-menu')]//a[contains(text(),'Profile')]"));
	    prof.click();
	    System.out.println("Clicked on Profile menu option");
	}

	@When("Profile page is displayed")
	public void profile_page_is_displayed() {
		driver.findElement(By.xpath("//li[contains(text(),\"Social network\")]")).isDisplayed();
		System.out.println("Profile Page is displayed");
	}

	@Then("Click on Message")
	public void click_on_Message() {
	    WebElement msg=driver.findElement(By.xpath("//li[contains(@class,'messages-icon')]"));
	    msg.click();
	    System.out.println("Clicked on Message link");
	}
	
	@When("ComposeMessage is shown")
	public void composemessage_is_shown() {
	    driver.findElement(By.xpath("//img[contains(@title,\"Compose message\")]")).isDisplayed();
	    System.out.println("Compose Message link is shown");
	}

	@Then("Click on ComposeMessage")
	public void click_on_ComposeMessage() {
	    WebElement compmsg=driver.findElement(By.xpath("//img[contains(@title,\"Compose message\")]"));
	    compmsg.click();
	    System.out.println("Clicked on Compose Message Button");
	}


	@When("ComposeMessage page is shown")
	public void composemessage_page_is_shown() {
	    driver.findElement(By.xpath("//li[contains(text(),'Compose message')]")).isDisplayed();
	    System.out.println("Compose Message page displayed");
	}

	@Then("Fill up the message form")
	public void fill_up_the_message_form() {
	    driver.findElement(By.xpath("//input[contains(@name,'title')]")).sendKeys("This is the Sankha Mukherjee");
	    System.out.println("Message Input given"); 
	}
	
	@Then("Click on Send Message btn")
	public void click_on_Send_Message_btn() {
	   WebElement sndmsg=driver.findElement(By.xpath("//button[contains(@name,'compose')]"));
	   sndmsg.click();
	   System.out.println("Message Sent");
	}


}
